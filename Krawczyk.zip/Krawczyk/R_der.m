function P_prime = R_der(x_init)
% Define Initial condition and Poincare section
tspan = [0, 3];
z_slice = 27;

D0 = eye(3);
v_rhs = @(t, v) reshape(lorenz_jacobian(t, reshape(v, [3, 3])), [], 1);

h = [0; 0; 1];

P_prime = {};

for i = 1:size(x_init,2)
    % Using the ODE solver to solve the trajectory of the Lorenz system
    [t, x] = rk4(@lorenz_rhs, tspan, x_init(:,i), tspan(2)/0.0002);
    
    % Find the state point of the Lorenz system at the Poincare cross-section
    % Find the first point that meets the condition that passes through the section from above
    for j = 3:length(t)
        if (x(j, 3) - z_slice) * (x(j-1, 3) - z_slice) < 0 && x(j, 3) - x(j-1, 3) >0
            y_idx = j;
            break;
        end
    end

    y = x(y_idx, :);
    
    tau = t(y_idx);
    
    [tv, D] = ode45(v_rhs, [tau, 0], D0);
    % D = D(end:-1:1, :);
    D = reshape(D(end,:), 3, 3);
    
    f_y = lorenz_rhs(0, y');
    correction = f_y * h' / (h' * f_y);
    
    P_prime{i} = eye(3) - correction;
    P_prime{i} = P_prime{i} * D;
end
end