function poincare_points = R(x_init)
sigma = 10;
rho = 28;
beta = 8/3;

dt = 0.0002;

poincare_coords = [0, 0, 27];

sign_init = sign(x_init(1,1)*x_init(2,1)-8/3*x_init(3,1));

x = x_init;

poincare_points = zeros(3,1);
count = 0;

% Run the numerical integration until the first Poincare section crossing
while true
    k1 = [sigma*(x(2)-x(1)); 
          x(1)*(rho-x(3))-x(2); 
          x(1)*x(2)-beta*x(3)];
    k2 = [sigma*((x(2)+0.5*dt*k1(2))-(x(1)+0.5*dt*k1(1))); 
          (x(1)+0.5*dt*k1(1)) * (rho-(x(3)+0.5*dt*k1(3))) - (x(2)+0.5*dt*k1(2));
          (x(1)+0.5*dt*k1(1)) * (x(2)+0.5*dt*k1(2)) - beta *(x(3)+0.5*dt*k1(3))];
    k3 = [sigma*((x(2)+0.5*dt*k2(2))-(x(1)+0.5*dt*k2(1))); 
          (x(1)+0.5*dt*k2(1)) * (rho-(x(3)+0.5*dt*k2(3))) - (x(2)+0.5*dt*k2(2));
          (x(1)+0.5*dt*k2(1)) * (x(2)+0.5*dt*k2(2)) - beta *(x(3)+0.5*dt*k2(3))];
    k4 = [sigma*((x(2)+dt*k3(2))-(x(1)+dt*k3(1))); 
          (x(1)+dt*k3(1)) * (rho-(x(3)+dt*k3(3))) - (x(2)+dt*k3(2));
          (x(1)+dt*k3(1)) * (x(2)+dt*k3(2)) - beta *(x(3)+dt*k3(3))];
      
    
    y = x(:);
    % Update the state vector based on the Runge-Kutta method
    x(:) = x(:) + dt * (1/6)*(k1+2*k2+2*k3+k4);

    % Check if the current state is on the Poincare section
    if y(3)<27 && x(3)>27 && count>0
        break;
    end
    count = count + 1;
end
% 
% Record the coordinates of the Poincare point
poincare_points(:) = [x(1); x(2);27];
end