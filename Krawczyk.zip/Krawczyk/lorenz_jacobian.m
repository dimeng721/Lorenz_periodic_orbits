function J = lorenz_jacobian(~, x)
% Jacobian matrix of Lorenz System

sigma = 10;
rho = 28;
beta = 8/3;

J = [-sigma, sigma, 0;
     rho - x(3), -1, -x(1);
     x(2), x(1), -beta];
end