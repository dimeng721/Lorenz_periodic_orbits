for i = 1:length(x)
    y = R_der(x);
    F_der(i) = eye(3) - y{i};
    C(i) = inv(F_der);
end

function K = Kraw(z)
    p = length(z);
    K = zeros(1,length(z));
    for i = 1:p
        z_hat = mid(z(:,i));
        K(i) = z_hat - C(i) * F(z_hat) - (C(i) * F_der(i) - eye(3)) * (z(:,i) - z_hat);
    end
end