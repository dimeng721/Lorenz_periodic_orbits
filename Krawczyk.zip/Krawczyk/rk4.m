function [t,y]=rk4(f,tspan,y0,n)
Runge-Kutta methods
h=(tspan(2)-tspan(1))/n;
t=tspan(1):h:tspan(2);
% y = intval(zeros(length(y0),length(t)));
y = zeros(length(y0),length(t));
y(:,1)=y0;
for m=2:length(t)
    k1=f(t(m-1),y(:,m-1));
    k2=f(t(m-1)+h/2,y(:,m-1)+k1*h/2);
    k3=f(t(m-1)+h/2,y(:,m-1)+k2*h/2);
    k4=f(t(m-1)+h,y(:,m-1)+k3*h);
    y(:,m)=y(:,m-1)+(k1+2*k2+2*k3+k4)*h/6;
end
t=t';
y=y';
end