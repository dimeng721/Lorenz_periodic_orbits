function y = F(z)
    % Defining the State Variables and Period Lengths of the Lorenz System
    x = z(1:3);
    p = length(x);
    
    % Calculate each component of F (z)
    f = zeros(1, p);
    for k = 1:p
        f(k) = mod(k, p) + 1;
    end
    y = x(:,f) - R(x);
end