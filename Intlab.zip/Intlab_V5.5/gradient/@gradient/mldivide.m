function r = mldivide(a,b)
%MLDIVIDE     Implements  a \ b  for gradient
%

% written  11/02/05     S.M. Rump
%

  r = b / a;
