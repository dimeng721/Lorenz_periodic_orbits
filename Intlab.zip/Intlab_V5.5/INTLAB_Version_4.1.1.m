%Help file for INTLAB Version 4.1.1
%
%Interval sqrt corrected because Matlab does not support sqrt with rounding (which is IEEE 754).
%
%Few minor changes and corrections.
%
