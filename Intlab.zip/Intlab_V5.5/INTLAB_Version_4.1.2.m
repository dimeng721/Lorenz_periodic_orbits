%Help file for INTLAB Version 4.1.2
%
%Accurate sum and dot product added (sum_ and dot_), and generation of ill-conditioned
%  dot products (gendot)
%
%Few minor changes and performance improvements.
%
