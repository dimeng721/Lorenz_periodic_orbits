function [C,d] = spdiags(A,d,B,n)
%SPDIAGS      Implements  spdiags  for intervals
%
% functionality as Matlab function spdiags for matrices
%

% written  07/08/02     S.M. Rump
% modified 04/04/04     S.M. Rump  set round to nearest for safety
% modified 04/06/05     S.M. Rump  rounding unchanged
%

  e = 1e-30;
  if 1+e==1-e                           % fast check for rounding to nearest
    rndold = 0;
  else
    rndold = getround;
    setround(0)
  end

  if nargin==1              % C = spdiags(A)  or  [C,d] = spdiags(A), A must be intval
    C.complex = A.complex;
    if C.complex            % A complex intval
      C.inf = [];
      C.sup = [];
      [C.mid,d] = spdiags(A.mid);
      if isequal(A.rad,0)
        C.rad = 0;
      else
        [C.rad,e] = spdiags(A.rad);
        if ~isequal(d,e)
          d = union(d,e);
          C.mid = spdiags(A.mid,d);
          C.rad = spdiags(A.rad,d);
        end
      end
    else                    % A real intval
      [C.inf,d] = spdiags(A.inf);
      [C.sup,e] = spdiags(A.sup);
      if ~isequal(d,e)
        d = union(d,e);
        C.inf = spdiags(A.inf,d);
        C.sup = spdiags(A.sup,d);
      end
      C.mid = [];
      C.rad = [];
    end
  elseif nargin==2        % C = spdiags(A,d)
    if isa(d,'intval')
      error('invalid call of intval/spdiags')
    end
    C.complex = A.complex;
    if C.complex
      C.inf = [];
      C.sup = [];
      C.mid = spdiags(A.mid,d);
      if isequal(A.rad,0)
        C.rad = 0;
      else
        C.rad = spdiags(A.rad,d);
      end
    else
      C.inf = spdiags(A.inf,d);
      C.sup = spdiags(A.sup,d);
      C.mid = [];
      C.rad = [];
    end
  elseif nargin==3        % C = spdiags(A,d,B)
    if isa(d,'intval')
      error('invalid call of intval/spdiags')
    end
    C = B;
    C.complex = A.complex;
    if C.complex
      C.inf = [];
      C.sup = [];
      C.mid = spdiags(A.mid,d);
      if isequal(A.rad,0)
        C.rad = 0;
      else
        C.rad = spdiags(A.rad,d);
      end
    else
      C.inf = spdiags(A.inf,d);
      C.sup = spdiags(A.sup,d);
      C.mid = [];
      C.rad = [];
    end
  elseif nargin==4        % C = spdiags(A,d,m,n), parameter m is B
    if isa(d,'intval')
      error('invalid call of intval/spdiags')
    end
    C.complex = A.complex;
    if C.complex
      C.inf = [];
      C.sup = [];
      C.mid = spdiags(A.mid,d,B,n);
      if isequal(A.rad,0)
        C.rad = 0;
      else
        C.rad = spdiags(A.rad,d,B,n);
      end
    else
      C.inf = spdiags(A.inf,d,B,n);
      C.sup = spdiags(A.sup,d,B,n);
      C.mid = [];
      C.rad = [];
    end
  end
  
  C = class(C,'intval');
    
  if rndold~=0
    setround(rndold)
  end
