function n = numel(varargin)
%NUMEL        Overloaded functions, necessary for Matlab V6.1f
%

% written  10/03/02     S.M. Rump
%

  n = 1;
