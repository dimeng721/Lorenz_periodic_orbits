function r = union(varargin)
%UNION        For interval union, please use "hull"
%

% written  10/31/07     S.M. Rump
%

  error('For interval union, please use "hull".')
  