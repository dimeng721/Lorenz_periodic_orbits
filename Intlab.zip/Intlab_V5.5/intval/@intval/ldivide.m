function c = ldivide(a,b)
%LDIVIDE      Interval elementwise left division a .\ b
%

% written  11/02/05     S.M. Rump
%

  c = b ./ a;
