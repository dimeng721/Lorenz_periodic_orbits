%Help file for INTLAB Version 5.3
%
% - gradient/hessian abs corrected
% - SparseInfNanFlag removed
% - gradient/hessian scalar+/-array corrected (thanks to S�bastien Loisel)
% - lssresidual splitting corrected
% - verifylss error message prevented (thanks to Jiri Rohn)
% - performance of isinf, isnan etc. for huge arrays
% - workaround for Matlab bug for norm
% - long/mtimes splitting corrected (thanks to Dirk Poot)
% - dimension check in isspd
%
